<?php include 'includes/header.php'; ?>
<h1>Bem-vindo ao meu projeto PHP</h1>
<p>Este é o arquivo principal.</p>
<?php include 'includes/footer.php'; ?>