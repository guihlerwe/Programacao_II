<?php include 'includes/header.php'; ?>
<h2>Contato</h2>
<form method="POST" action="processa.php">
    <label>Nome:</label><br>
    <input type="text" name="nome"><br><br>
    <button type="submit">Enviar</button>
</form>
<?php include 'includes/footer.php'; ?>