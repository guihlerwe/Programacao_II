<hr>
<footer>
    <p>© <?php echo date('Y'); ?> - Desenvolvido por Guilherme</p>
</footer>
<script src="assets/js/script.js"></script>
</body>
</html>