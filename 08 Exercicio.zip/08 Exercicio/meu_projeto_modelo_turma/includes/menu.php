<nav>
    <a href="index.php">Início</a> |
    <a href="sobre.php">Sobre</a> |
    <a href="contato.php">Contato</a>
</nav>
<hr>