<?php include 'includes/header.php'; ?>
<h2>Sobre</h2>
<p>Exemplo de página sobre.</p>
<?php include 'includes/footer.php'; ?>